angular.module('Medicare')
        .controller('SignInCtrl', ["$scope", function($scope) {
        }]);
