angular.module('Medicare')
        .controller('QueryCtrl', ["$scope", function($scope) {
        }]);
