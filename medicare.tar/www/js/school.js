angular.module('Medicare')
        .controller('SchoolCtrl', ["$scope", function($scope) {
        }]);
