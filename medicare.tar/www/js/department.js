angular.module('Medicare')
        .controller('DepartmentCtrl', ["$scope", function($scope) {
        }]);
