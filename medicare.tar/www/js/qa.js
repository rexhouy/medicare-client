angular.module('Medicare')
        .controller('QaCtrl', ["$scope", function($scope) {
        }]);
