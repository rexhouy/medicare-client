angular.module('Medicare')
        .controller('InfoCtrl', ["$scope", function($scope) {
        }]);
