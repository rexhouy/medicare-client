angular.module('Medicare')
        .controller('InfoCompanyCtrl', ["$scope", function($scope) {
        }]);
