angular.module('Medicare')
        .controller('NavigationCtrl', ["$scope", function($scope) {
        }]);
