angular.module('Medicare')
        .controller('MeCtrl', ["$scope", function($scope) {
        }]);
