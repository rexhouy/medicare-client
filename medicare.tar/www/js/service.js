angular.module('Medicare')
        .controller('ServiceCtrl', ["$scope", function($scope) {
        }]);
