angular.module('Medicare')
        .controller('BookCtrl', ["$scope", function($scope) {
        }]);
