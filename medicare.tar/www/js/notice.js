angular.module('Medicare')
        .controller('NoticeCtrl', ["$scope", function($scope) {
        }]);
