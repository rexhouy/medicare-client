angular.module('Medicare')
        .controller('StatusCtrl', ["$scope", function($scope) {
        }]);
