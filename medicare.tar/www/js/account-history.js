angular.module('Medicare')
        .controller('AccountHistoryCtrl', ["$scope", "$routeParams", "$location", function($scope, $routeParams, $location) {
        }]);
