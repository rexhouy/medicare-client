angular.module('Medicare')
        .controller('NewsCtrl', ["$scope", function($scope) {
        }]);
