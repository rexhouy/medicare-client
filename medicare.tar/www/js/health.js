angular.module('Medicare')
        .controller('HealthCtrl', ["$scope", function($scope) {
        }]);
